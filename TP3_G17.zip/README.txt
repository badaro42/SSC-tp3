﻿java AuthServer2

java p1.ProxyClient user password "authserver address"

java Streamcast /tmp/streaming.dat